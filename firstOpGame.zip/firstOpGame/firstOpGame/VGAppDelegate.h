//
//  VGAppDelegate.h
//  firstOpGame
//
//  Created by JiangHuifu on 14-5-22.
//  Copyright (c) 2014年 veger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VGAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
