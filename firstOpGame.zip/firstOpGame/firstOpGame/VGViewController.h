//
//  VGViewController.h
//  firstOpGame
//
//  Created by JiangHuifu on 14-5-22.
//  Copyright (c) 2014年 veger. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface VGViewController : GLKViewController

@end
